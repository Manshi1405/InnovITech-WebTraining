<?php

$lang['first'] = 'First';
$lang['last'] = 'Last';
$lang['next'] = 'Next';
$lang['previous'] = 'Previous';
