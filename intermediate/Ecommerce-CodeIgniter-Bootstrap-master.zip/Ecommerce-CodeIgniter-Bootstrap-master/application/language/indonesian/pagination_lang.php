<?php

$lang['first'] = 'Pertama';
$lang['last'] = 'Terakhir';
$lang['next'] = 'Selanjutnya';
$lang['previous'] = 'Sebelumnya';
