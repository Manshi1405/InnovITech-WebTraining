<?php 
$lang['first'] = 'Premier';
$lang['last'] = 'Dernier';
$lang['next'] = 'Suivant';
$lang['previous'] = 'Précédent';
