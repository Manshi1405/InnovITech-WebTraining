<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <div class="body">
        <div class="dynPage bottom-30">
            <div class="text-content">
                <?= $content ?>
            </div>
        </div>
        <?php include 'bodyFooter.php' ?>
    </div>
</div>